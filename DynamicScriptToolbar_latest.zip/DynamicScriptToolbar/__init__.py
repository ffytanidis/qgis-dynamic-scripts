def classFactory(iface):
    from .main import DynamicScriptToolbar
    return DynamicScriptToolbar(iface)